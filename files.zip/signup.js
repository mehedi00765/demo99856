var cfg = window.PEACE_CONFIG;
var msg = document.getElementById("msg");
var btn = document.getElementById("signupBtn");
var emailInput = document.getElementById("email");

var prefill = new URLSearchParams(window.location.search).get("email");
if (prefill) emailInput.value = prefill;

function show(text, ok) {
  msg.textContent = text;
  msg.style.color = ok ? "#14663A" : "#B42318";
}

var configured = cfg && cfg.SUPABASE_URL.indexOf("YOUR_") !== 0;
var db = configured ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;

btn.addEventListener("click", async function () {
  var storeName = document.getElementById("storeName").value.trim();
  var email = emailInput.value.trim();
  var password = document.getElementById("password").value;

  if (!storeName || !email || password.length < 8) {
    show("Enter a store name, a valid email and a password of at least 8 characters.", false);
    return;
  }
  if (!db) {
    show("Supabase is not set up yet. Add your project URL and anon key in js/config.js.", false);
    return;
  }
  btn.disabled = true;
  show("Creating your account...", true);
  var res = await db.auth.signUp({
    email: email,
    password: password,
    options: { data: { store_name: storeName } },
  });
  btn.disabled = false;
  if (res.error) {
    show(res.error.message, false);
  } else {
    show("Account created. Check your email to confirm it.", true);
  }
});
