# Peace store

Landing page and sign-up page for the Peace online store builder. Plain HTML, CSS and JavaScript. Supabase handles accounts.

## Files
- `index.html` landing page
- `signup.html` sign-up page, creates an account with Supabase Auth
- `js/config.js` your Supabase URL and anon key
- `js/signup.js`, `js/landing.js` page scripts

## Set up Supabase
1. Create a project at supabase.com.
2. In Settings > API copy the Project URL and the anon public key into `js/config.js`.
3. In Authentication > Providers keep Email enabled. The store name is saved with each user as `store_name` in their metadata.

## Run locally
Open `index.html` in a browser, or run `python3 -m http.server` in this folder and visit http://localhost:8000.

## Upload to GitHub (run on your own computer)
```
cd peace-store
git init
git add .
git commit -m "Peace landing and sign-up pages"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```
When Git asks for a password, use a GitHub personal access token (Settings > Developer settings > Personal access tokens), not your account password.

## Host it
Turn on GitHub Pages (Settings > Pages > deploy from `main`) or connect the repo to Netlify or Vercel.
