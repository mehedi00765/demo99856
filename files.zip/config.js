// Fill these in from your Supabase project: Settings > API.
// The anon key is meant to be public, but never put the service_role key here.
window.PEACE_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY",
};
