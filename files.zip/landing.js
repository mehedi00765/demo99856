// Send the email typed on the landing page to the sign-up page.
document.getElementById("heroBtn").addEventListener("click", function () {
  var email = document.getElementById("heroEmail").value.trim();
  window.location.href = "signup.html" + (email ? "?email=" + encodeURIComponent(email) : "");
});
